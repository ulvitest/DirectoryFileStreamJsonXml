﻿using System;
using System.IO;
using System.Xml.Serialization;

namespace DirectoryFileStreamReader
{
    class Program
    {
        static void Main(string[] args)
        {
            #region
            //Directory.CreateDirectory(@"C:\Users\user\Desktop\Test");
            //Directory.CreateDirectory(@"C:\Users\user\Desktop\Lorem");
            //Directory.CreateDirectory(@"C:\Users\user\Desktop\Lorem\Tset");
            //Directory.Delete(@"C:\Users\user\Desktop\Lorem\",true);
            //if (Directory.Exists(@"C:\Users\user\Desktop\Lorem\Tset"))
            //{
            //    Directory.Delete(@"C:\Users\user\Desktop\Lorem\Tset");
            //}
            //Directory.GetDirectories(@"C:\Users\user\Desktop\Test");
            //string[]arr= Directory.GetFiles(@"C:\Users\user\Desktop\Test");
            // foreach (var item in arr)
            // {
            //     Console.WriteLine(item);
            // }

            //if (File.Exists(@"C:\Users\user\Desktop\Test\blabla.txt"))
            //{
            //    //File.Create(@"C:\Users\user\Desktop\Test\blabla.txt");
            //    File.Delete(@"C:\Users\user\Desktop\Test\blabla.txt");
            //}
            //Directory.CreateDirectory(@"C:\Users\user\Desktop\Test");
            //File.Create(@"C:\Users\user\Desktop\Test\blabla.txt");

            //StreamWriter sw = new StreamWriter(@"C:\Users\user\Desktop\Test\blabla.txt", true);
            //sw.WriteLine("Nurlan");
            //sw.Close();

            //StreamReader sw1 = new StreamReader(@"C:\Users\user\Desktop\Test\blabla.txt", true);
            //string result = sw1.ReadToEnd();
            //Console.WriteLine(result);
            //sw1.Close();

            //using (StreamWriter sw = new StreamWriter(@"C:\Users\user\Desktop\Test\blabla.txt", true))
            //{
            //    sw.WriteLine("Nurlan");
            //}
            //using(StreamReader sw=new StreamReader(@"C:\Users\user\Desktop\Test\blabla.txt", true))
            //{
            //    string result = sw.ReadToEnd();
            //    Console.WriteLine(result);
            //}
            #endregion
            #region
            //Product p1 = new Product { Id = 1, Name = "Iphone", Price = 1000 };
            //Product p2 = new Product { Id = 2, Name = "Samsung", Price = 500 };

            //ProductItem productItem = new ProductItem { Id = 1, TotalPrice = p1.Price, Product = p1 };
            //ProductItem productItem1 = new ProductItem { Id = 2, TotalPrice = p2.Price, Product = p2 };

            //List<ProductItem> list = new List<ProductItem>();
            //list.Add(productItem);
            //list.Add(productItem1);


            //ProductItems productItems = new ProductItems { Id = 1, productItems = list };
            //string result=JsonConvert.SerializeObject(productItems);
            //using (StreamWriter sw = new StreamWriter(@"C:\Users\user\Desktop\DirectoryFileStreamReader\DirectoryFileStreamReader\Json\json1.json", true))
            //{
            //    sw.WriteLine(result);
            //}
            //  string result;
            //  using (StreamReader sw = new StreamReader(@"C:\Users\user\Desktop\DirectoryFileStreamReader\DirectoryFileStreamReader\Json\json1.json", true))
            //  {
            //       result = sw.ReadToEnd();
            //      //Console.WriteLine(result);
            //  }
            //ProductItems list= JsonConvert.DeserializeObject<ProductItems>(result);
            //  Console.WriteLine(list.productItems[0].Product.Name);


            StreamReader stream;
                ValCurs test=null;
            using (stream = new StreamReader(@"C:\Users\user\Desktop\DirectoryFileStreamReader\DirectoryFileStreamReader\Json\XMLFile1.xml", true))
            {
                //result = stream.ReadToEnd();
                //Console.WriteLine(result);
                XmlSerializer serializer = new XmlSerializer(typeof(ValCurs));
                test = (ValCurs)serializer.Deserialize(stream);
            }


            foreach (var item in test.ValType)
            {
                foreach (var i in item.Valute)
                {
                    Console.WriteLine(i.Name);
                }

            }

            #endregion
        }
    }
}
