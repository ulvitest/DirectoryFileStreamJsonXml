﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DirectoryFileStreamReader.Models
{
    class ProductItem
    {
        public int Id { get; set; }
        public Product Product { get; set; }
        public double TotalPrice { get; set; }
    }
}
