﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DirectoryFileStreamReader.Models
{
    class ProductItems
    {
        public int Id { get; set; }
        public List<ProductItem> productItems { get; set; }
    }
}
